<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>MasseurMatch — Coming Soon</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');

  body {
    margin: 0;
    height: 100vh;
    font-family: 'Inter', sans-serif;
    background: url('/AmdhFQbU.png') no-repeat center center/cover;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    overflow: hidden;
  }

  .content {
    text-align: center;
    animation: fadeIn 2s ease-out;
  }

  .logo {
    width: 150px;
    margin-bottom: 10px;
  }

  h1 {
    font-size: 2.8rem;
    font-weight: 600;
    background: linear-gradient(135deg, #b5c7d8, #87a7c4, #e0d5b3);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin: 10px 0;
  }

  h2 {
    font-size: 1.2rem;
    font-weight: 400;
    opacity: 0;
    background: linear-gradient(135deg, #d3d3d3, #a5b1bc, #f2e5c4);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: fadeInText 2s ease 2s forwards;
  }

  @keyframes fadeIn {
    from {opacity: 0; transform: translateY(30px);}
    to {opacity: 1; transform: translateY(0);}
  }

  @keyframes fadeInText {
    to {opacity: 1;}
  }

  /* Chatbox */
  #chat-box {
    position: fixed;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    width: 70%;
    max-width: 800px;
    background: rgba(10,10,10,0.7);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 40px;
    display: flex;
    align-items: center;
    padding: 12px 18px;
    backdrop-filter: blur(8px);
    box-shadow: 0 0 25px rgba(255,255,255,0.1);
  }

  #user-input {
    flex: 1;
    background: transparent;
    border: none;
    outline: none;
    color: #fff;
    font-size: 16px;
    padding: 10px 14px;
  }

  #send-btn {
    background: #fff;
    color: #000;
    border: none;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    font-size: 18px;
    cursor: pointer;
    transition: 0.2s;
  }

  #send-btn:hover {
    background: #00b7ff;
    color: #fff;
    transform: scale(1.05);
  }

  #chat-response {
    position: fixed;
    bottom: 90px;
    left: 50%;
    transform: translateX(-50%);
    width: 70%;
    max-width: 800px;
    background: rgba(255,255,255,0.07);
    color: #fff;
    border-radius: 20px;
    padding: 18px;
    font-size: 15px;
    display: none;
    backdrop-filter: blur(6px);
  }

  @media (max-width: 800px) {
    #chat-box, #chat-response { width: 90%; }
    h1 { font-size: 2rem; }
  }
</style>
</head>
<body>

<div class="content">
  <img src="/AmdhFQbU.png" alt="" class="logo" style="display:none;">
  <h1>MASSEURMATCH<br>COMING SOON!</h1>
  <h2>Smarter matches. Better experiences.</h2>
</div>

<div id="chat-response"></div>
<div id="chat-box">
  <input id="user-input" type="text" placeholder="Type a message to Knotty..." />
  <button id="send-btn">↑</button>
</div>

<script>
  const input = document.getElementById('user-input');
  const send = document.getElementById('send-btn');
  const chatResp = document.getElementById('chat-response');

  async function sendMsg() {
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    chatResp.style.display = 'block';
    chatResp.textContent = 'Knotty is thinking...';

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ message: msg })
      });
      const data = await res.json();
      chatResp.textContent = data.reply || 'Something went wrong.';
    } catch {
      chatResp.textContent = 'Error reaching Knotty. Try again.';
    }
  }

  send.onclick = sendMsg;
  input.addEventListener('keypress', e => { if (e.key === 'Enter') sendMsg(); });

  window.onload = () => {
    chatResp.style.display = 'block';
    chatResp.textContent = "Hey there 👋 I’m Knotty — your chat buddy from MasseurMatch!";
  };
</script>

</body>
</html>
